# Measles Detection Web App — Full Process Guide

## 0. Architecture at a glance

```
[ Browser ]                     [ Flask Backend ]                 [ Your Model ]
 index.html  --image + symptoms-->  /predict endpoint  --calls-->  image_feature_model.h5
 script.js   <----JSON result-----  (app.py)            <--------  fusion_model.h5
```

The frontend never talks to the model directly. It sends a normal
HTTP POST (multipart form: image file + symptom fields) to your
Flask API. Flask preprocesses the inputs, runs your trained model,
and sends back a small JSON object that the frontend renders.

---

## 1. Prepare your trained model (you already have the training code)

Your paper's architecture is a **multimodal fusion model**:

1. **Image branch** – a CNN (e.g. EfficientNetB0/ResNet50 transfer
   learning, or your custom CNN) that turns a skin image into a
   feature embedding (e.g. a 1280-d vector).
2. **Symptom branch** – clinical features (fever, cough, Koplik
   spots, rash, days since rash onset, etc.) fed through a small
   MLP or used directly as numeric input.
3. **Fusion head** – concatenate the image embedding + symptom
   vector, pass through 1–2 dense layers, output a single sigmoid
   probability: `P(measles)`.

After training, **export three artifacts**:

| File | What it is |
|---|---|
| `image_feature_model.h5` | CNN that maps image → embedding |
| `fusion_model.h5` | Takes `[embedding, symptom_vector]` → probability |
| `symptom_scaler.pkl` | The `StandardScaler`/`MinMaxScaler` fit on your training symptom data (so live inputs get scaled the same way) |

```python
# at the end of your training notebook/script
image_model.save("image_feature_model.h5")
fusion_model.save("fusion_model.h5")

import pickle
with open("symptom_scaler.pkl", "wb") as f:
    pickle.dump(symptom_scaler, f)
```

Drop all three files into `backend/models/`.

> If you trained a **single end-to-end model** instead of two
> separate ones, that's fine too — just simplify `model_utils.py`
> to load one model and call `model.predict([image_tensor, symptom_vector])`.

---

## 2. Backend (Flask API)

Files: `backend/app.py`, `backend/model_utils.py`, `backend/requirements.txt`

- `app.py` — defines `POST /predict`. Reads the uploaded image +
  symptom form fields, calls the helper functions, and returns
  JSON: `{ prediction, confidence, feedback, disclaimer }`.
- `model_utils.py` — **this is the only file you need to edit** to
  plug in your real model. It has three functions:
  - `load_models()` — loads your `.h5` files once at startup
  - `preprocess_image()` — resize/normalize (must match training!)
  - `build_symptom_vector()` / `predict_measles()` — assembles
    features and runs inference

**Run it:**
```bash
cd backend
pip install -r requirements.txt
python app.py
# API now running at http://127.0.0.1:5000
```

Until you add your real `.h5` files, the app runs in a built-in
**demo mode** (a simple placeholder formula) so you can test the
full website flow immediately, before your model is even ready.

---

## 3. Frontend

Files: `frontend/index.html`, `style.css`, `script.js`

- Upload box with image preview
- Checkboxes for each clinical symptom (fever, cough, Koplik spots,
  conjunctivitis, rash, etc.) + a "days since rash onset" field
- On submit, `script.js` sends a `FormData` POST to your Flask API
  (`API_URL` at the top of `script.js`)
- Renders: a colored badge (Measles / Not Measles), a confidence
  bar, plain-language feedback, and a medical disclaimer

**Run it:** just open `frontend/index.html` in a browser (or serve
it with any static server, e.g. `python -m http.server 8000` from
inside the `frontend/` folder). Make sure the Flask backend is
running at the same time.

---

## 4. Connecting them

`script.js` has one line to check:
```js
const API_URL = "http://127.0.0.1:5000/predict";
```
Change this to your deployed backend URL once you host it.
CORS is already enabled in `app.py` (`flask-cors`) so the frontend
can call the backend from a different port/domain.

---

## 5. Testing the full pipeline

1. Start backend: `python backend/app.py`
2. Open `frontend/index.html`
3. Upload a skin photo, check a few symptoms, click **Analyze**
4. You should see a JSON-driven result card appear with a
   prediction, confidence %, and feedback text

Once this works end-to-end in demo mode, drop in your real
`.h5` files and re-test — no other code changes needed.

---

## 6. Deployment options

| Component | Easy options |
|---|---|
| Backend (Flask + model) | Render, Railway, PythonAnywhere, Hugging Face Spaces (Gradio/Flask), a small VPS |
| Frontend (static files) | Netlify, Vercel, GitHub Pages, or just have Flask serve the `frontend/` folder directly with `send_from_directory` |

**Simplest option for a thesis demo:** serve everything from one
Flask app — put `frontend/` files in a `static/` folder and add a
route that returns `index.html`. Then you only need to deploy one
service.

---

## 7. Important things to keep matched between training and serving

- **Image size** — `IMAGE_SIZE` in `model_utils.py` must equal what
  you used during training (e.g. 224×224).
- **Normalization** — if you trained with `/255.0` scaling, or with
  `preprocess_input()` from Keras applications, use the *exact
  same* function at inference time.
- **Symptom feature order** — the order of fields in
  `build_symptom_vector()` must match the column order your model
  was trained on.
- **Scaler** — always transform live symptom inputs with the same
  scaler object you fit during training, not a new one.

---

## 8. Ethical/medical disclaimer (already built into the UI)

Because this touches health diagnosis, the result card always shows:
> "This tool is a research prototype and does NOT replace
> professional medical diagnosis. Always consult a qualified clinician."

Keep this visible in your deployed version and in your thesis
write-up — it's both good practice and something examiners will
look for in a health-AI project.
