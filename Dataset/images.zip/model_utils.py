"""
model_utils.py
--------------
This is where YOUR trained model plugs in.

Your project fuses two modalities:
  (A) Skin image  -> CNN feature extractor (e.g. EfficientNetB0 / ResNet50 / your own CNN)
  (B) Clinical symptoms -> numeric feature vector (fever, rash, Koplik spots, etc.)

The two feature sets are concatenated and passed through a fusion
(dense) head that outputs a single probability: P(measles).

Replace the paths / architecture below with whatever you actually
trained and exported. Everything else in app.py stays the same as
long as these three functions keep the same input/output shape.
"""

import numpy as np
import pickle
import os

# Uncomment whichever framework you trained with:
# import tensorflow as tf
# from tensorflow.keras.models import load_model
# import torch

MODELS_DIR = os.path.join(os.path.dirname(__file__), "models")
IMAGE_SIZE = (224, 224)   # must match the input size used during training


def load_models():
    """
    Load the trained image model, fusion model, and symptom scaler
    ONCE when the server starts.

    Expected files in backend/models/:
      - image_feature_model.h5   (CNN, outputs a feature embedding, e.g. 1280-d)
      - fusion_model.h5          (takes [image_features, symptom_vector] -> probability)
      - symptom_scaler.pkl       (sklearn StandardScaler/MinMaxScaler fit on training symptoms)
    """
    image_model_path = os.path.join(MODELS_DIR, "image_feature_model.h5")
    fusion_model_path = os.path.join(MODELS_DIR, "fusion_model.h5")
    scaler_path = os.path.join(MODELS_DIR, "symptom_scaler.pkl")

    # --- TensorFlow/Keras example (uncomment once your .h5 files exist) ---
    # image_model = load_model(image_model_path)
    # fusion_model = load_model(fusion_model_path)

    # --- Placeholder so the app runs before you drop your real model in ---
    image_model = None
    fusion_model = None

    if os.path.exists(scaler_path):
        with open(scaler_path, "rb") as f:
            symptom_scaler = pickle.load(f)
    else:
        symptom_scaler = None

    if image_model is None:
        print("[WARNING] No trained model found in backend/models/. "
              "Running in DEMO mode with a dummy predictor. "
              "Add your .h5 files to get real predictions.")

    return image_model, fusion_model, symptom_scaler


def preprocess_image(pil_image):
    """
    Resize + normalize the uploaded image exactly the way you
    preprocessed images during training (this MUST match training
    preprocessing or accuracy will silently degrade).
    """
    pil_image = pil_image.resize(IMAGE_SIZE)
    img_array = np.array(pil_image).astype("float32") / 255.0  # scale to [0,1]
    img_array = np.expand_dims(img_array, axis=0)  # add batch dimension -> (1,224,224,3)
    return img_array


def build_symptom_vector(symptom_raw: dict, scaler):
    """
    Convert the raw form values (strings like "on"/"1"/"0") into a
    numeric feature vector in the SAME order used during training.
    """
    order = [
        "fever", "cough", "runny_nose", "red_watery_eyes",
        "koplik_spots", "rash_present", "days_since_rash_onset",
    ]

    vector = []
    for key in order:
        val = symptom_raw.get(key, 0)
        if key == "days_since_rash_onset":
            vector.append(float(val) if val not in ("", None) else 0.0)
        else:
            # checkbox-style fields arrive as "on"/"true"/"1" or missing
            vector.append(1.0 if str(val).lower() in ("on", "true", "1", "yes") else 0.0)

    vector = np.array(vector).reshape(1, -1)

    if scaler is not None:
        vector = scaler.transform(vector)

    return vector


def predict_measles(image_model, fusion_model, image_tensor, symptom_vector):
    """
    Runs the two-stage forward pass:
      1. image_model(image_tensor) -> image_features
      2. fusion_model([image_features, symptom_vector]) -> probability

    Returns: {"label": "Measles" | "Not Measles", "confidence": float 0-1}
    """
    if image_model is None or fusion_model is None:
        # ---------------- DEMO MODE ----------------
        # Deterministic-ish placeholder so the frontend/backend
        # integration can be tested end-to-end before your real
        # model files are dropped into backend/models/.
        rash_present = symptom_vector[0][5]
        koplik = symptom_vector[0][4]
        fake_score = 0.3 + 0.25 * rash_present + 0.25 * koplik
        fake_score = min(fake_score, 0.97)
        label = "Measles" if fake_score >= 0.5 else "Not Measles"
        return {"label": label, "confidence": float(fake_score)}

    # ---------------- REAL MODEL ----------------
    image_features = image_model.predict(image_tensor, verbose=0)
    probability = fusion_model.predict(
        [image_features, symptom_vector], verbose=0
    )[0][0]

    label = "Measles" if probability >= 0.5 else "Not Measles"
    confidence = probability if label == "Measles" else 1 - probability
    return {"label": label, "confidence": float(confidence)}
