"""
Measles Detection API
----------------------
Flask backend that exposes a /predict endpoint.
The frontend sends: 1 image file + clinical symptom flags.
This file preprocesses both inputs, runs them through the
trained multimodal model, and returns a JSON result.

Run:  python app.py
"""

import os
import io
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image

from model_utils import (
    load_models,
    preprocess_image,
    build_symptom_vector,
    predict_measles,
)

app = Flask(__name__)
CORS(app)  # allow the frontend (different port/origin) to call this API

# ---------------------------------------------------------------------
# Load model(s) ONCE at startup (not per-request -> much faster)
# ---------------------------------------------------------------------
IMAGE_MODEL, FUSION_MODEL, SYMPTOM_SCALER = load_models()

# Symptom fields the frontend form must send (order matters for the model!)
SYMPTOM_FIELDS = [
    "fever",
    "cough",
    "runny_nose",
    "red_watery_eyes",   # conjunctivitis
    "koplik_spots",      # small white spots inside mouth
    "rash_present",
    "days_since_rash_onset",  # numeric, 0 if no rash yet
]


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "message": "Measles detection API running"})


@app.route("/predict", methods=["POST"])
def predict():
    # ---- 1. Validate inputs -------------------------------------------------
    if "image" not in request.files:
        return jsonify({"error": "No image file uploaded"}), 400

    image_file = request.files["image"]
    if image_file.filename == "":
        return jsonify({"error": "Empty image filename"}), 400

    try:
        # ---- 2. Read + preprocess image -------------------------------
        img_bytes = image_file.read()
        pil_image = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        image_tensor = preprocess_image(pil_image)  # shape (1, H, W, 3), normalized

        # ---- 3. Build symptom feature vector ---------------------------
        symptom_raw = {}
        for field in SYMPTOM_FIELDS:
            value = request.form.get(field, 0)
            symptom_raw[field] = value
        symptom_vector = build_symptom_vector(symptom_raw, SYMPTOM_SCALER)

        # ---- 4. Run multimodal inference --------------------------------
        result = predict_measles(IMAGE_MODEL, FUSION_MODEL, image_tensor, symptom_vector)

        # ---- 5. Build human-readable feedback ---------------------------
        confidence_pct = round(result["confidence"] * 100, 2)
        if result["label"] == "Measles":
            if result["confidence"] >= 0.85:
                feedback = (
                    f"High likelihood of measles ({confidence_pct}% confidence) based on "
                    "the skin image and reported symptoms. Please seek medical evaluation "
                    "promptly, especially if Koplik spots or fever with rash are present."
                )
            else:
                feedback = (
                    f"Possible measles indicators detected ({confidence_pct}% confidence). "
                    "The result is not fully certain — clinical confirmation is recommended."
                )
        else:
            feedback = (
                f"The image and symptoms are more consistent with a non-measles condition "
                f"({100 - confidence_pct}% confidence against measles). If symptoms persist "
                "or worsen, please consult a healthcare provider."
            )

        return jsonify({
            "prediction": result["label"],
            "confidence": confidence_pct,
            "feedback": feedback,
            "disclaimer": (
                "This tool is a research prototype and does NOT replace professional "
                "medical diagnosis. Always consult a qualified clinician."
            ),
        })

    except Exception as e:
        return jsonify({"error": f"Prediction failed: {str(e)}"}), 500


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
