// Point this at wherever your Flask backend is running.
// Local dev default:
const API_URL = "http://127.0.0.1:5000/predict";

const form = document.getElementById("predict-form");
const imageInput = document.getElementById("image-input");
const preview = document.getElementById("preview");
const uploadText = document.getElementById("upload-text");
const submitBtn = document.getElementById("submit-btn");

const resultCard = document.getElementById("result-card");
const loading = document.getElementById("loading");
const resultContent = document.getElementById("result-content");
const errorContent = document.getElementById("error-content");

const badge = document.getElementById("badge");
const confidenceBar = document.getElementById("confidence-bar");
const confidenceText = document.getElementById("confidence-text");
const feedbackText = document.getElementById("feedback-text");
const disclaimerText = document.getElementById("disclaimer-text");

// Show a preview of the chosen image
imageInput.addEventListener("change", () => {
  const file = imageInput.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    preview.src = e.target.result;
    preview.style.display = "block";
    uploadText.style.display = "none";
  };
  reader.readAsDataURL(file);
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  submitBtn.disabled = true;
  submitBtn.textContent = "Analyzing…";

  resultCard.classList.remove("hidden");
  loading.classList.remove("hidden");
  resultContent.classList.add("hidden");
  errorContent.classList.add("hidden");

  const formData = new FormData(form);

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      body: formData,
    });
    const data = await response.json();

    loading.classList.add("hidden");

    if (!response.ok) {
      throw new Error(data.error || "Something went wrong");
    }

    // Populate result UI
    badge.textContent = data.prediction;
    badge.className = "badge " + (data.prediction === "Measles" ? "measles" : "not-measles");

    confidenceBar.style.width = data.confidence + "%";
    confidenceText.textContent = `Confidence: ${data.confidence}%`;
    feedbackText.textContent = data.feedback;
    disclaimerText.textContent = data.disclaimer;

    resultContent.classList.remove("hidden");
  } catch (err) {
    loading.classList.add("hidden");
    errorContent.classList.remove("hidden");
    errorContent.querySelector(".error-text").textContent =
      "Error: " + err.message + " (Is the backend running at " + API_URL + "?)";
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "Analyze";
  }
});
